
### Anahita Taheri


### Personal informations

---
+ name: Anahita
+ last name : Taheri
+ Date of birth : 1979/November/29
+ I am a trader and IT engineering student
+ location : Tehran , I.R.Iran


### Skill Highlights

---
+ trade on Tehran Stock Exchange and Forex
+ translating


### Education

---
+ Diploma : Aeen Tarbiat high school
+ Bachelor of science : IT Engineering
_ payam Noor University of North 

### language

---
+ Persian
+ English

### Favorites

---
+ Trade
+ Studing historical books
+ travel 
+ playing volleyball

### working Experience

---
+ I am working in Caltural,Turism & Handicrafts Minister.




--- 
### [رزومه فارسی](resume-fa.md)
